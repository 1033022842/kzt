<?php

declare(strict_types=1);

use think\facade\Route;

Route::group('api/v1/auth', function () {
    Route::post('register', 'app\controller\AuthController@register');
    Route::post('login', 'app\controller\AuthController@login');
})->allowCrossDomain();

Route::group('api/v1', function () {
    Route::group('streamer', function () {
        Route::get('configs/:id', 'app\controller\StreamerController@detail');
        Route::get('configs', 'app\controller\StreamerController@configs');
        Route::post('upload-avatar', 'app\controller\StreamerController@uploadAvatar');
        Route::post('configs', 'app\controller\StreamerController@create');
        Route::put('configs', 'app\controller\StreamerController@update');
        Route::delete('configs/:id', 'app\controller\StreamerController@delete');
    });

    Route::group('admin', function () {
        Route::get('users/configs', 'app\controller\AdminController@usersConfigs');
        Route::put('training-status', 'app\controller\AdminController@toggleTrainingStatus');
    });
})->middleware(\app\middleware\Auth::class)
  ->allowCrossDomain();
