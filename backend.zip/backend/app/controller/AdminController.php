<?php

declare(strict_types=1);

namespace app\controller;

use app\BaseController;
use app\common\exception\BusinessException;
use app\common\web\ResultCode;
use app\model\StreamerConfig;
use app\model\User;

final class AdminController extends BaseController
{
    protected bool $requireAuth = true;

    public function usersConfigs()
    {
        $user = User::find($this->getAuthUserId());
        if (!$user || $user->role !== 'admin') {
            throw new BusinessException(ResultCode::ACCESS_TOKEN_INVALID, '无权限访问');
        }

        $params = $this->request->get();
        $pageSize = (int) ($params['pageSize'] ?? 20);
        $pageNum = (int) ($params['pageNum'] ?? 1);

        $query = StreamerConfig::with(['user'])
            ->order('update_time', 'desc');

        $paginator = $query->paginate([
            'list_rows' => $pageSize,
            'page' => $pageNum,
        ]);

        $list = [];
        foreach ($paginator->items() as $item) {
            $data = $item->toArray();
            if ($item->user) {
                $data['username'] = $item->user->username;
                $data['nickname'] = $item->user->nickname;
                $data['user_info'] = [
                    'username' => $item->user->username,
                    'nickname' => $item->user->nickname,
                ];
            }
            unset($data['user']);
            $list[] = $data;
        }

        return $this->successPaginate($list, $paginator->total());
    }

    public function toggleTrainingStatus()
    {
        $user = User::find($this->getAuthUserId());
        if (!$user || $user->role !== 'admin') {
            throw new BusinessException(ResultCode::ACCESS_TOKEN_INVALID, '无权限访问');
        }

        $params = $this->request->put();
        $configId = $params['id'] ?? null;
        $newStatus = $params['training_status'] ?? null;

        if (!$configId || !in_array($newStatus, ['normal', 'training'], true)) {
            throw new BusinessException(ResultCode::PARAM_ERROR, '参数错误');
        }

        $config = StreamerConfig::find($configId);
        if (!$config) {
            throw new BusinessException(ResultCode::PARAM_ERROR, '配置不存在');
        }

        $config->training_status = $newStatus;
        $config->save();

        return $this->success(['training_status' => $config->training_status]);
    }
}
