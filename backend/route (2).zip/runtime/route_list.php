Route List
+------------------------------+---------------------------------------------+--------+---------------------------------------------+
| Rule                         | Route                                       | Method | Name                                        |
+------------------------------+---------------------------------------------+--------+---------------------------------------------+
| api/v1/auth/register         | app\controller\AuthController@register      | post   | app\controller\AuthController@register      |
| api/v1/auth/login            | app\controller\AuthController@login         | post   | app\controller\AuthController@login         |
| api/v1/streamer/configs/<id> | app\controller\StreamerController@detail    | get    | app\controller\StreamerController@detail    |
| api/v1/streamer/configs/<id> | app\controller\StreamerController@delete    | delete | app\controller\StreamerController@delete    |
| api/v1/streamer/configs      | app\controller\StreamerController@configs   | get    | app\controller\StreamerController@configs   |
| api/v1/streamer/configs      | app\controller\StreamerController@create    | post   | app\controller\StreamerController@create    |
| api/v1/streamer/configs      | app\controller\StreamerController@update    | put    | app\controller\StreamerController@update    |
| api/v1/admin/users/configs   | app\controller\AdminController@usersConfigs | get    | app\controller\AdminController@usersConfigs |
+------------------------------+---------------------------------------------+--------+---------------------------------------------+
